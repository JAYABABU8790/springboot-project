package com.glca.app.service;

import com.glca.app.entity.User;

public interface IUserService {
	User addUser(User user);

}
