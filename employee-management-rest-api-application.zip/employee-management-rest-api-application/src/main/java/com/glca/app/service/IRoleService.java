package com.glca.app.service;

import com.glca.app.entity.Role;

public interface IRoleService {
	Role addRole(Role role);
}
